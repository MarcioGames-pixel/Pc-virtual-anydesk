const fs = require("fs");
const path = require("path");

const usersPath = path.join(__dirname, "users");
const catalogPath = path.join(__dirname, "catalog");

function loadUser(userId) {
    const file = path.join(usersPath, `${userId}.json`);

    if (!fs.existsSync(file))
        return null;

    try {
        return JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (err) {
        console.error(`[CATALOG] Failed to read user ${userId}:`, err);
        return null;
    }
}

function getHat(id) {
    if (!id)
        return null;

    const directory = path.join(
        catalogPath,
        "hats",
        String(id)
    );

    const mesh = path.join(directory, "mesh.obj");

    if (!fs.existsSync(mesh)) {
        console.log(`[CATALOG] Hat ${id} not found.`);
        return null;
    }

    return {
        id,
        mesh,
        directory
    };
}

function loadTool(id) {
    if (!id)
        return null;

    const file = path.join(
        catalogPath,
        "tools",
        `${id}.js`
    );

    if (!fs.existsSync(file)) {
        console.log(`[CATALOG] Tool ${id} not found.`);
        return null;
    }

    delete require.cache[require.resolve(file)];

    return require(file);
}

Game.on("playerJoin", async (player) => {
    const userId = player.userId || player.id || 1;
    const user = loadUser(userId);

    if (!user || !user.avatar || !user.avatar.assets)
        return;

    const assets = user.avatar.assets;

    const hatId = assets.hat1 || 0;
    const toolId = assets.tool || 0;

    console.log(
        `[CATALOG] ${user.username}: hat1=${hatId}, tool=${toolId}`
    );

    /*
     * Apply the local hat to the player's avatar.
     */
    if (hatId) {
        const hat = getHat(hatId);

        if (hat) {
            player.assets.hat1 = hatId;

            console.log(
                `[CATALOG] Hat ${hatId} assigned to ${user.username}: ${hat.mesh}`
            );
        }
    }

    /*
     * Load the catalog tool.
     */
    if (toolId) {
        const setup = loadTool(toolId);

        if (!setup)
            return;

        const tool = new Tool(
            setup.name || `Tool ${toolId}`
        );

        if (typeof setup.setup === "function")
            setup.setup(tool);

        try {
            await player.addTool(tool);

            console.log(
                `[CATALOG] Tool ${toolId} added to ${user.username}.`
            );
        } catch (err) {
            console.error(
                `[CATALOG] Failed to add Tool ${toolId}:`,
                err
            );
        }
    }
});
