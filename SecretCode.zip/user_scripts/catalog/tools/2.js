module.exports = {
    name: "Brick Tool",

    model: 2,

    setup(tool) {
        tool.model = 2;
    }
};
