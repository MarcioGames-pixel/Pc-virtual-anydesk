'use strict';
/*
 * Kamcord local server (revival) - v2
 * Baseado nas rotas/modelos extraídos do APK 1.7-38 (Retrofit AppServer).
 * Códigos de status reais do app: OK=0, USER_NOT_AUTHORIZED=1, COULD_NOT_SET_TOKEN=2,
 * INSUFFICIENT_PARAMETERS=3, UNABLE_TO_DELETE_TOKEN=4, PAGE_OUT_OF_BOUNDS=7,
 * GENERIC_ERROR=8, ENTITY_NOT_FOUND=9, USER_BLOCKED=10.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');

const PORT = Number(process.env.PORT) || 42480;
const ROOT = process.env.KAMCORD_STORAGE || path.join(os.homedir(), 'kamcord-storage');
const MEDIA = path.join(ROOT, 'kamcord-local');
const PARTS = path.join(ROOT, 'multipart');
const THUMBS = path.join(ROOT, 'thumbs');
// KAMCORD_OPEN=1: sem token, usa a última conta (só para testes, como a versão antiga).
const OPEN_MODE = process.env.KAMCORD_OPEN === '1';
for (const d of [ROOT, MEDIA, PARTS, THUMBS]) fs.mkdirSync(d, { recursive: true });

/* ---------- armazenamento JSON ---------- */
const F = {
  accounts: 'accounts.json', games: 'games.json', uploads: 'uploads.json',
  videos: 'videos.json', likes: 'likes.json', comments: 'comments.json',
  follows: 'follows.json', settings: 'account-settings.json', streams: 'streams.json',
  messages: 'stream-messages.json'
};
function rj(name, fb) {
  try { return JSON.parse(fs.readFileSync(path.join(ROOT, F[name] || name), 'utf8')); }
  catch { return fb; }
}
function wj(name, data) {
  const file = path.join(ROOT, F[name] || name);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, file);
}
const arr = v => (Array.isArray(v) ? v : []);
const nowIso = () => new Date().toISOString().replace(/\.\d+Z$/, 'Z');

/* ---------- migração do formato antigo ---------- */
function migrate() {
  if (!fs.existsSync(path.join(ROOT, F.videos))) {
    const videos = [];
    const old = arr(rj('videos-catalog.json', []));
    const uploads = arr(rj('uploads', []));
    for (const v of old) {
      if (!v || !v.video_id || !v._key) continue;
      videos.push({
        video_id: v.video_id, title: v.title || 'Video', game_primary_id: v.game_primary_id || '',
        user_id: v.user_id || 'local', duration: Number(v.duration) || 0, key: v._key,
        views: v.views || 0, featured: !!v.featured, upload_time: v.upload_time || nowIso()
      });
    }
    for (const u of uploads) {
      if (u && u.type === 's3-complete' && /^videos\//.test(u.key || '') &&
          !videos.some(v => v.key === u.key) &&
          fs.existsSync(path.join(MEDIA, u.key))) {
        const id = 'local-' + Buffer.from(u.key).toString('hex').slice(0, 48);
        videos.push({ video_id: id, title: path.parse(u.key).name, game_primary_id: '',
          user_id: 'local', duration: 0, key: u.key, views: 0, featured: false,
          upload_time: u.created_at || nowIso() });
      }
    }
    wj('videos', videos);
  }
  const gf = rj('game-follows.json', null);
  if (gf && !fs.existsSync(path.join(ROOT, F.follows))) {
    const out = {};
    for (const [uid, games] of Object.entries(gf)) out[uid] = { users: [], games: arr(games).map(String) };
    wj('follows', out);
  }
}
migrate();

/* ---------- imagem padrão (o app não aceita URL de imagem nula/vazia) ---------- */
const PLACEHOLDER = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAABQklEQVR42u3QWzoCYBSG0T0SQtL5nGO4q3RQFEVRlPlPwT+Cb1/s2/d51giWHeV7EIwCgqJBfQh2XOhDIMgPGkAgyAvKFAcQUtATBIIICgadlIYQCCIoHDSCYKflEQSC/KAxBIK8oLPKGEIKmkAgiKBgULb6DIEggsJBUwh2XptCIMgPmkEgyAvK1WcQUtALBIIICgZdNF4hEERQOGgOwfLNOQSC/KAFBIK8oEJrASEFvUEgiKBgULH9DoEggsJBSwhW6iwhEOQHrSAQ5AWVL1cQUtAHBIIICgZVrj4hEERQOGgNwarXawgE+UEbCAR5QbWbDYQU9AWBIIKCQfXbbwgEERQO2kKwxt0WAkF+0A4CQV5Qs7uDkIJ+IBBEUDCodf8LgSCCwkF7CNZ+2EMgyA86QCDIC+o8HiCkoD8IBBEU8w8iYBt4ktP6XQAAAABJRU5ErkJggg==', 'base64');
let CUR_BASE = `http://127.0.0.1:${PORT}`;
const phUrl = () => `${CUR_BASE}/placeholder.png`;
const phThumbs = () => ({ small: phUrl(), medium: phUrl(), large: phUrl() });

/* ---------- respostas ---------- */
function send(res, status, body, type = 'application/json', extra = {}) {
  res.writeHead(status, { 'Content-Type': type, 'Access-Control-Allow-Origin': '*', ...extra });
  res.end(body);
}
const json = (res, data, status = 200) => send(res, status, JSON.stringify(data));
const ok = (res, response = {}) =>
  json(res, { status: { status_code: 0, status_reason: 'All ok.' }, response });
const fail = (res, code, reason, response = null) =>
  json(res, { status: { status_code: code, status_reason: reason }, response });
const E = {
  auth: res => fail(res, 1, 'User not authorized for action.'),
  params: res => fail(res, 3, 'Insufficient parameters.'),
  page: res => fail(res, 7, 'Page out of bounds.'),
  generic: (res, m) => fail(res, 8, m || 'Generic error.'),
  notFound: res => fail(res, 9, 'Entity not found.')
};
const xml = (res, body) =>
  send(res, 200, '<?xml version="1.0" encoding="UTF-8"?>' + body, 'application/xml');

function readBody(req) {
  return new Promise((resolve, reject) => {
    const c = [];
    req.on('data', d => c.push(d));
    req.on('end', () => resolve(Buffer.concat(c)));
    req.on('error', reject);
  });
}
async function fields(req) { // JSON ou form-urlencoded
  const t = (await readBody(req)).toString('utf8');
  if (!t) return {};
  try { const v = JSON.parse(t); if (v && typeof v === 'object') return v; } catch {}
  return Object.fromEntries(new URLSearchParams(t));
}
const base = req => {
  const proto = String(req.headers['x-forwarded-proto'] || 'http').split(',')[0];
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || `127.0.0.1:${PORT}`).split(',')[0];
  return `${proto}://${host}`;
};
function paginate(list, url, defCount = 20) {
  const count = Math.min(100, Math.max(1, parseInt(url.searchParams.get('count'), 10) || defCount));
  const page = Math.max(0, parseInt(url.searchParams.get('page'), 10) || 0);
  const items = list.slice(page * count, (page + 1) * count);
  return { items, next_page: (page + 1) * count < list.length ? String(page + 1) : null };
}

/* ---------- contas ---------- */
// O app faz Color.parseColor(profile_color): precisa ser hexadecimal (#RRGGBB), nunca "default".
const DEFAULT_COLOR = '#7E57C2';
const colorOf = c => (/^#[0-9a-fA-F]{6}$/.test(String(c || '')) ? String(c) : DEFAULT_COLOR);
const accounts = () => arr(rj('accounts', []));
function accountResponse(a) {
  return { id: String(a.id), username: a.username, email: a.email, token: a.token,
    color: colorOf(a.color), email_verified: !!a.email_verified,
    first_login: !!a.first_login, sharer: !!a.sharer };
}
function auth(req) {
  const h = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
  const token = h || String(req.headers['x-auth-token'] || '');
  const list = accounts();
  const a = token && list.find(x => x.token && x.token === token);
  if (a) return a;
  return OPEN_MODE ? list[list.length - 1] || null : null;
}
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64);
// UserErrorCode: USERNAME_TAKEN=1 SHORT=2 LONG=3 INVALID_CHARS=4 EMAIL_TAKEN=5 INVALID=6 LONG=7
// USERNAME_MISSING=14 EMAIL_MISSING=15 GENERIC=18 PASSWORD_SHORT=21 LONG=22 MISSING=23
function checkUsername(u, exceptId) {
  if (!u) return 14;
  if (u.length < 3) return 2;
  if (u.length > 20) return 3;
  if (!/^[A-Za-z0-9_.-]+$/.test(u)) return 4;
  if (accounts().some(a => a.username.toLowerCase() === u.toLowerCase() && String(a.id) !== String(exceptId))) return 1;
  return 0;
}
function checkEmail(e, exceptId) {
  if (!e) return 15;
  if (e.length > 254) return 7;
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) return 6;
  if (accounts().some(a => (a.email || '').toLowerCase() === e.toLowerCase() && String(a.id) !== String(exceptId))) return 5;
  return 0;
}
function checkPassword(p) {
  if (!p) return 23;
  if (p.length < 6) return 21;
  if (p.length > 64) return 22;
  return 0;
}
const codeResp = code => ({ error_code: code });

/* ---------- jogos / seguidores ---------- */
const follows = () => rj('follows', {});
const fol = (all, uid) => all[uid] || (all[uid] = { users: [], games: [] });
const games = () => {
  const g = rj('games', []);
  return arr(Array.isArray(g) ? g : g && g.game_list).filter(x => x && x.game_primary_id);
};
const gameKeys = g => [String(g.game_primary_id), g.play_store_id, g.app_store_id].filter(Boolean).map(String);
const findGame = id => games().find(g => gameKeys(g).includes(String(id)));
function gameJson(g, viewer, ctx) {
  const all = (ctx && ctx.follows) || follows();
  const vids = (ctx && ctx.videos) || arr(rj('videos', []));
  const id = String(g.game_primary_id);
  const followers = Object.values(all).filter(f => arr(f.games).includes(id)).length;
  const players = new Set(vids.filter(v => String(v.game_primary_id) === id).map(v => v.user_id));
  return {
    app_store_id: g.app_store_id || '', app_store_url: g.app_store_url || '',
    coverart_image_url: g.coverart_image_url || phUrl(), game_primary_id: id,
    icons: { regular: (g.icons && g.icons.regular) || phUrl() },
    isInstalled: !!g.isInstalled, isRecording: false,
    is_user_following: !!(viewer && arr(all[String(viewer.id)] && all[String(viewer.id)].games).includes(id)),
    name: g.name, number_of_followers: followers, number_of_players: players.size,
    number_of_videos: vids.filter(v => String(v.game_primary_id) === id).length,
    play_store_id: g.play_store_id || '', play_store_url: g.play_store_url || '',
    went_live_time: g.went_live_time || null
  };
}

/* ---------- usuários ---------- */
const thumbs3 = phThumbs;
function userJson(id, viewer, ctx) {
  const c = ctx || {};
  const all = c.follows || follows();
  const vids = c.videos || arr(rj('videos', []));
  const likes = c.likes || rj('likes', {});
  id = String(id);
  const acc = accounts().find(a => String(a.id) === id);
  if (!acc && id !== 'local') return null;
  const mine = vids.filter(v => String(v.user_id) === id);
  const followers = Object.entries(all).filter(([, f]) => arr(f.users).includes(id)).length;
  const vf = viewer && all[String(viewer.id)];
  const st = (rj('streams', {})[id] || {});
  return {
    id, username: acc ? acc.username : 'local', tagline: (acc && acc.tagline) || '',
    profile_color: colorOf(acc && acc.color),
    avatar_thumbnails: thumbs3(), profile_thumbnails: thumbs3(),
    followers_count: followers,
    following_count: arr(all[id] && all[id].users).length,
    like_count: Object.values(likes).filter(l => arr(l).includes(id)).length,
    likes_received: mine.reduce((n, v) => n + arr(likes[v.video_id]).length, 0),
    reshare_count: 0, reshares_received: 0,
    video_count: mine.length, view_count: 0,
    views_received: mine.reduce((n, v) => n + (v.views || 0), 0),
    donations_enabled: false, email_verified: !!(acc && acc.email_verified),
    isFollowForFollow: false, isFromAccount: !!(viewer && String(viewer.id) === id),
    hasJustFollowed: false,
    is_following_requesting_user: !!(viewer && arr(all[id] && all[id].users).includes(String(viewer.id))),
    is_user_following: !!(vf && arr(vf.users).includes(id)),
    permissions: [], groups: [], stream_state: st.live ? 'LIVE' : 'OFFLINE'
  };
}

/* ---------- vídeos ---------- */
const videoOk = v => {
  try { return fs.statSync(path.join(MEDIA, v.key)).size > 1024; } catch { return false; }
};
const videos = () => arr(rj('videos', [])).filter(videoOk);
const allVideosRaw = () => arr(rj('videos', []));
function mkCtx() { return { follows: follows(), videos: videos(), likes: rj('likes', {}), comments: rj('comments', {}) }; }
function videoJson(v, req, viewer, ctx, withGame = true) {
  const b = base(req);
  const likes = arr(ctx.likes[v.video_id]);
  const g = findGame(v.game_primary_id);
  const thumb = fs.existsSync(path.join(THUMBS, v.video_id + '.jpg'))
    ? `${b}/kamcord-thumb/${encodeURIComponent(v.video_id)}.jpg` : phUrl();
  return {
    video_id: v.video_id, title: v.title, game_primary_id: g ? String(g.game_primary_id) : (v.game_primary_id || ''),
    game_name: g ? g.name : '', game: g && withGame ? gameJson(g, viewer, ctx) : null,
    user_id: String(v.user_id), username: (userJson(v.user_id, null, ctx) || {}).username || 'local',
    user: userJson(v.user_id, viewer, ctx),
    duration: Number(v.duration) || 0, comments: arr(ctx.comments[v.video_id]).length,
    hearts: likes.length, likes: likes.length, reshares: 0, views: v.views || 0,
    featured: !!v.featured, is_user_liking: !!(viewer && likes.includes(String(viewer.id))),
    is_user_resharing: false, vod: true, video_state: 'PROCESSED',
    video_url: `${b}/kamcord-media/${v.key.split('/').map(encodeURIComponent).join('/')}`,
    video_site_watch_page: `${b}/app/v3/videos/${encodeURIComponent(v.video_id)}`,
    thumbnails: { regular: thumb, small: thumb },
    upload_time: v.upload_time, source: { message: '', type: 'USER_VIDEO', eventDate: v.upload_time }
  };
}
const byRecent = (a, b) => String(b.upload_time).localeCompare(String(a.upload_time));
const score = v => (v.views || 0) + 1;
function sortFeed(list, type, likes) {
  const l = [...list];
  if (type === 'POPULAR' || type === 'TRENDING')
    return l.sort((a, b) => (arr(likes[b.video_id]).length * 5 + score(b)) - (arr(likes[a.video_id]).length * 5 + score(a)) || byRecent(a, b));
  if (type === 'MOST_VIEWED') return l.sort((a, b) => (b.views || 0) - (a.views || 0) || byRecent(a, b));
  if (type === 'FEATURED') return l.filter(v => v.featured).sort(byRecent);
  return l.sort(byRecent);
}
const vCard = (v, req, viewer, ctx, title) => ({
  card_type: 'VIDEO', action_type: 'VIDEO', images: { banner: phUrl(), icon: phUrl() }, title: title || v.title,
  sub_title: (userJson(v.user_id, null, ctx) || {}).username || '', video: videoJson(v, req, viewer, ctx)
});
const gCard = (g, viewer, ctx) => ({ card_type: 'GAME', action_type: 'GAME', images: { banner: phUrl(), icon: phUrl() }, title: g.name, sub_title: '', game: gameJson(g, viewer, ctx) });
const uCard = (u) => ({ card_type: 'USER', action_type: 'USER', images: { banner: phUrl(), icon: phUrl() }, title: u.username, sub_title: u.tagline || '', user: u });
const group = (type, title, id, cards, next = null) =>
  ({ group_type: type, title, feed_id: id, card_models: cards, next_page: next });

/* ---------- streams ---------- */
const streams = () => rj('streams', {});
function streamJson(id, req) {
  const s = streams()[String(id)] || {};
  const acc = accounts().find(a => String(a.id) === String(id));
  const g = s.game_id ? findGame(s.game_id) : null;
  const msgs = arr(rj('messages', {})[String(id)]);
  return {
    connected: !!s.connected, current_viewers_count: 0, ended_at: s.ended_at || null,
    game: g ? gameJson(g, null) : null, game_id: s.game_id || '', heart_count: s.heart_count || 0,
    live: !!s.live, max_viewers_count: 0, message_count: msgs.length, name: s.name || '',
    play: { hls: s.live && s.hls ? s.hls : null, rtmp: s.live ? (s.url || null) : null },
    started_at: s.started_at || null, stream_id: String(id), stream_session_id: s.stream_session_id || '',
    thumbnails: phThumbs(), total_viewers_count: 0,
    type: 'LIVE', user: acc ? userJson(acc.id, null) : null, user_id: String(id), video_id: ''
  };
}

/* ---------- mídia: duração e miniatura (ffmpeg opcional) ---------- */
function processMedia(video) {
  const file = path.join(MEDIA, video.key);
  execFile('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file],
    { timeout: 20000 }, (e, out) => {
      const d = parseFloat(out);
      if (!e && d > 0) {
        const list = allVideosRaw(); const v = list.find(x => x.video_id === video.video_id);
        if (v) { v.duration = d; wj('videos', list); }
      }
    });
  execFile('ffmpeg', ['-y', '-v', 'error', '-ss', '1', '-i', file, '-frames:v', '1', '-vf', 'scale=480:-2',
    path.join(THUMBS, video.video_id + '.jpg')], { timeout: 30000 }, (e) => {
    if (e) execFile('ffmpeg', ['-y', '-v', 'error', '-i', file, '-frames:v', '1', '-vf', 'scale=480:-2',
      path.join(THUMBS, video.video_id + '.jpg')], { timeout: 30000 }, () => {});
  });
}
function log(item) {
  const db = arr(rj('uploads', [])); db.push({ ...item, created_at: nowIso() });
  wj('uploads', db.slice(-500));
}

/* ---------- multipart S3 ---------- */
const sessions = new Map();
const safeKey = k => {
  const clean = String(k).split('/').filter(p => p && p !== '.' && p !== '..').map(p => p.replace(/[^\w.\-]/g, '_'));
  return clean.join('/');
};
function saveStream(req, file) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('md5'); let n = 0;
    const out = fs.createWriteStream(file);
    req.on('data', c => { h.update(c); n += c.length; });
    req.pipe(out);
    out.on('finish', () => resolve({ etag: h.digest('hex'), size: n }));
    out.on('error', reject); req.on('error', reject);
  });
}
function registerVideoFile(key, ownerHint) {
  // Vincula o arquivo concluído a uma reserva (video_id + título + dono).
  const rs = arr(rj('uploads', [])).filter(x => x.type === 'reserve' && x.video_key === key).pop();
  const list = allVideosRaw();
  if (!/^videos\//.test(key)) return;
  const id = rs ? rs.video_id : 'local-' + Buffer.from(key).toString('hex').slice(0, 48);
  if (list.some(v => v.video_id === id)) return;
  const v = {
    video_id: id, title: (rs && rs.title) || path.parse(key).name,
    game_primary_id: (rs && rs.game_id) || '', description: (rs && rs.description) || '',
    user_id: (rs && rs.user_id) || ownerHint || 'local', duration: 0, key,
    views: 0, featured: false, upload_time: nowIso()
  };
  list.push(v); wj('videos', list); processMedia(v);
}

/* ---------- servidor ---------- */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    let p;
    try { p = decodeURIComponent(url.pathname); } catch { return E.params(res); }
    const M = req.method;
    console.log('[REQ]', M, p, url.search);
    CUR_BASE = base(req);
    if (M === 'GET' && p === '/placeholder.png') return send(res, 200, PLACEHOLDER, 'image/png', { 'Cache-Control': 'max-age=86400' });

    if (M === 'OPTIONS') {
      res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': '*' });
      return res.end();
    }
    if (p === '/health') return json(res, { ok: true, service: 'Kamcord local server', port: PORT });

    /* mídia */
    if ((M === 'GET' || M === 'HEAD') && (p.startsWith('/kamcord-media/') || p.startsWith('/kamcord-thumb/'))) {
      const isThumb = p.startsWith('/kamcord-thumb/');
      const rel = p.slice(isThumb ? 15 : 15);
      const dir = isThumb ? THUMBS : MEDIA;
      const file = path.resolve(dir, rel);
      if (!file.startsWith(path.resolve(dir) + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile())
        return json(res, { error: 'Media not found' }, 404);
      const size = fs.statSync(file).size;
      const ext = path.extname(file).toLowerCase();
      const type = { '.mp4': 'video/mp4', '.m4v': 'video/x-m4v', '.webm': 'video/webm', '.m4a': 'audio/mp4', '.jpg': 'image/jpeg' }[ext] || 'application/octet-stream';
      const h = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*' };
      const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
      if (req.headers.range && !m) { res.writeHead(416, { 'Content-Range': `bytes */${size}` }); return res.end(); }
      if (m) {
        let s = m[1] ? +m[1] : 0, e = m[2] ? +m[2] : size - 1;
        if (!m[1] && m[2]) { s = Math.max(0, size - +m[2]); e = size - 1; }
        e = Math.min(e, size - 1);
        if (s >= size || e < s) { res.writeHead(416, { 'Content-Range': `bytes */${size}` }); return res.end(); }
        res.writeHead(206, { ...h, 'Content-Length': e - s + 1, 'Content-Range': `bytes ${s}-${e}/${size}` });
        return M === 'HEAD' ? res.end() : fs.createReadStream(file, { start: s, end: e }).pipe(res);
      }
      res.writeHead(200, { ...h, 'Content-Length': size });
      return M === 'HEAD' ? res.end() : fs.createReadStream(file).pipe(res);
    }

    /* S3 virtual: /kamcord-local/<key> */
    const s3 = p.match(/^\/kamcord-local\/(.+)$/);
    if (s3 && !p.startsWith('/app/')) {
      const key = safeKey(s3[1]);
      const uploadId = url.searchParams.get('uploadId');
      const partNumber = url.searchParams.get('partNumber');
      if (!key) return json(res, { error: 'Invalid key' }, 400);
      if (M === 'POST' && url.searchParams.has('uploads')) {
        await readBody(req);
        const id = crypto.randomUUID();
        sessions.set(id, { key, parts: new Map() });
        fs.mkdirSync(path.join(PARTS, id), { recursive: true });
        console.log('[MULTIPART START]', key, id);
        return xml(res, `<InitiateMultipartUploadResult><Bucket>kamcord-local</Bucket><Key>${key}</Key><UploadId>${id}</UploadId></InitiateMultipartUploadResult>`);
      }
      if (M === 'PUT' && uploadId && partNumber) {
        const s = sessions.get(uploadId);
        const n = Number(partNumber);
        if (!s) return json(res, { error: 'Invalid UploadId' }, 404);
        if (!Number.isInteger(n) || n < 1) return json(res, { error: 'Invalid partNumber' }, 400);
        const file = path.join(PARTS, uploadId, `${n}.part`);
        const { etag, size } = await saveStream(req, file);
        s.parts.set(n, { file, etag });
        console.log('[PART]', n, size, 'bytes');
        res.writeHead(200, { ETag: `"${etag}"`, 'Content-Length': '0', 'Access-Control-Allow-Origin': '*' });
        return res.end();
      }
      if (M === 'POST' && uploadId) {
        const s = sessions.get(uploadId);
        if (!s) return json(res, { error: 'Invalid UploadId' }, 404);
        const body = (await readBody(req)).toString('utf8');
        let order = [...body.matchAll(/<PartNumber>\s*(\d+)\s*<\/PartNumber>/g)].map(m => +m[1]);
        if (!order.length) order = [...s.parts.keys()].sort((a, b) => a - b);
        if (!order.length || order.some(n => !s.parts.has(n))) return json(res, { error: 'Missing multipart parts' }, 400);
        const dest = path.join(MEDIA, s.key);
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, '');
        for (const n of order) fs.appendFileSync(dest, fs.readFileSync(s.parts.get(n).file));
        const size = fs.statSync(dest).size;
        sessions.delete(uploadId);
        fs.rmSync(path.join(PARTS, uploadId), { recursive: true, force: true });
        log({ type: 's3-complete', bucket: 'kamcord-local', key: s.key, file: dest, size });
        registerVideoFile(s.key);
        console.log('[COMPLETE]', dest, size);
        const etag = crypto.createHash('md5').update(String(uploadId)).digest('hex') + '-' + order.length;
        return xml(res, `<CompleteMultipartUploadResult><Bucket>kamcord-local</Bucket><Key>${s.key}</Key><ETag>"${etag}"</ETag></CompleteMultipartUploadResult>`);
      }
      if (M === 'DELETE' && uploadId) {
        sessions.delete(uploadId);
        fs.rmSync(path.join(PARTS, uploadId), { recursive: true, force: true });
        res.writeHead(204); return res.end();
      }
      if (M === 'PUT') {
        const dest = path.join(MEDIA, key);
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        const { etag, size } = await saveStream(req, dest);
        log({ type: 's3-complete', bucket: 'kamcord-local', key, file: dest, size });
        registerVideoFile(key);
        res.writeHead(200, { ETag: `"${etag}"`, 'Content-Length': '0', 'Access-Control-Allow-Origin': '*' });
        return res.end();
      }
      return json(res, { error: 'Unsupported operation' }, 400);
    }

    /* ---------- API ---------- */
    const me = auth(req);
    let m;

    // Diagnóstico: KAMCORD_EMPTY=hero,games,creators,home,discovery devolve essas telas vazias
    const EMPTY = new Set((process.env.KAMCORD_EMPTY || '').split(',').map(x => x.trim()).filter(Boolean));
    if (EMPTY.size && M === 'GET') {
      const emptyGroup = (t, id) => ok(res, group(t, '', id, [], null));
      if (EMPTY.has('games') && p === '/app/v3/games') return emptyGroup('DETAIL', 'games');
      if (EMPTY.has('creators') && p === '/app/v3/users/creators') return emptyGroup('WHO_TO_FOLLOW', 'creators');
      if (EMPTY.has('home') && p === '/app/v4/feeds/androidfeed/') return ok(res, { card_model_list: [], next_page: null });
      if (EMPTY.has('discovery') && p === '/app/v4/feeds/discovery/') return ok(res, { group_set: { groups: [], next_page: null }, video_feeds: { feed_list: [] } });
      if (EMPTY.has('hero') && /^\/app\/v4\/feeds\/(?!game\/|discovery\/|androidfeed\/)[^/]+$/.test(p)) return emptyGroup('HERO', 'hero');
    }

    // Analytics
    if (M === 'POST' && p === '/v1/trackevent') {
      await readBody(req);
      return json(res, { status_code: 'OK', status_reason: 'ok', response: {}, retriable: false });
    }
    if (M === 'POST' && p === '/v2/cards/create.json') { await readBody(req); return ok(res); }

    // Experimentos
    if (M === 'POST' && p === '/app/v4/experiments/parameters') {
      await readBody(req);
      return ok(res, { experiments: [] });
    }

    /* conta */
    if (M === 'POST' && p === '/app/v3/account/create') {
      const f = await fields(req);
      const username = String(f.username || '').trim(), email = String(f.email || '').trim(), password = String(f.password || '');
      if (!username || !email || !password) return E.params(res);
      const code = checkUsername(username) || checkEmail(email) || checkPassword(password);
      if (code) return E.generic(res, 'Invalid account fields (error_code ' + code + ').');
      const list = accounts();
      const salt = crypto.randomBytes(16).toString('hex');
      const a = {
        id: String(list.reduce((mx, x) => Math.max(mx, Number(x.id) || 0), 0) + 1), username, email, salt,
        password_hash: hashPw(password, salt).toString('hex'), token: crypto.randomBytes(24).toString('hex'),
        color: DEFAULT_COLOR, email_verified: false, first_login: true, sharer: false, created_at: nowIso()
      };
      list.push(a); wj('accounts', list);
      return ok(res, accountResponse(a));
    }
    if (M === 'POST' && p === '/app/v3/account/login') {
      const f = await fields(req);
      const u = String(f.username || '').trim().toLowerCase();
      const list = accounts();
      const a = list.find(x => x.username.toLowerCase() === u || (x.email || '').toLowerCase() === u);
      if (!a || !a.salt) return E.auth(res);
      const sup = hashPw(String(f.password || ''), a.salt), exp = Buffer.from(a.password_hash, 'hex');
      if (sup.length !== exp.length || !crypto.timingSafeEqual(sup, exp)) return E.auth(res);
      a.token = crypto.randomBytes(24).toString('hex');
      const resp = accountResponse(a);       // first_login é devolvido antes de limpar
      a.first_login = false;
      wj('accounts', list);
      return ok(res, resp);
    }
    if (M === 'POST' && p === '/app/v3/account/logout') {
      await readBody(req);
      if (me) { const list = accounts(); const a = list.find(x => x.id === me.id); a.token = ''; wj('accounts', list); }
      return ok(res);
    }
    if (M === 'GET' && p === '/app/v4/account') return me ? ok(res, accountResponse(me)) : E.auth(res);
    if (M === 'GET' && p === '/app/v3/account/username/validate') return ok(res, codeResp(checkUsername(String(url.searchParams.get('username') || '').trim(), me && me.id)));
    if (M === 'GET' && p === '/app/v3/account/email/validate') return ok(res, codeResp(checkEmail(String(url.searchParams.get('email') || '').trim(), me && me.id)));
    if (M === 'GET' && p === '/app/v3/account/password/validate') return ok(res, codeResp(checkPassword(String(url.searchParams.get('password') || ''))));
    if (M === 'POST' && p === '/app/v3/account/email/set') {
      const f = await fields(req); if (!me) return E.auth(res);
      const email = String(f.email || '').trim(); if (checkEmail(email, me.id)) return E.generic(res, 'Invalid email.');
      const list = accounts(); const a = list.find(x => x.id === me.id); a.email = email; a.email_verified = false; wj('accounts', list);
      return ok(res);
    }
    if (M === 'POST' && p === '/app/v3/account/password/set') {
      const f = await fields(req); if (!me) return E.auth(res);
      const pw = String(f.password || ''); if (checkPassword(pw)) return E.generic(res, 'Invalid password.');
      const list = accounts(); const a = list.find(x => x.id === me.id);
      a.salt = crypto.randomBytes(16).toString('hex'); a.password_hash = hashPw(pw, a.salt).toString('hex'); wj('accounts', list);
      return ok(res);
    }
    if (M === 'POST' && p === '/app/v3/account/password/reset') { await readBody(req); return ok(res); } // sem e-mail local
    if (M === 'POST' && p === '/app/v3/account/email/sendverification') { await readBody(req); return ok(res, codeResp(0)); }
    if (M === 'POST' && p === '/app/v3/account/tagline/set') {
      const f = await fields(req); if (!me) return E.auth(res);
      const list = accounts(); list.find(x => x.id === me.id).tagline = String(f.tagline || '').slice(0, 250); wj('accounts', list);
      return ok(res);
    }
    if (M === 'POST' && (m = p.match(/^\/app\/v3\/users\/([^/]+)\/color\/set$/))) {
      const f = await fields(req); if (!me || String(me.id) !== m[1]) return E.auth(res);
      const list = accounts(); list.find(x => x.id === me.id).color = colorOf(f.color); wj('accounts', list);
      return ok(res);
    }
    if (M === 'POST' && (p === '/app/v4/token/set' || p === '/app/v4/account/token/delete')) { await readBody(req); return ok(res); }

    // Notificações: o app envia push_comments, push_follows... (sem _enabled)
    const defSet = { push_chat_enabled: false, push_comments_enabled: false, push_follows_enabled: false, push_interact_video_enabled: false, push_likes_enabled: false, push_mentions_enabled: false, push_reshare_enabled: false };
    if (M === 'GET' && p === '/app/v4/account/settings') {
      if (!me) return E.auth(res);
      return ok(res, { ...defSet, ...(rj('settings', {})[me.id] || {}) });
    }
    if (M === 'POST' && p === '/app/v4/account/settings/set') {
      const f = await fields(req); if (!me) return E.auth(res);
      const b = v => v === true || /^(true|1|yes|on)$/i.test(String(v));
      const all = rj('settings', {}); const cur = { ...defSet, ...(all[me.id] || {}) };
      const map = { push_comments: 'push_comments_enabled', push_follows: 'push_follows_enabled', push_likes: 'push_likes_enabled', push_chat: 'push_chat_enabled', push_mentions: 'push_mentions_enabled', push_reshares: 'push_reshare_enabled', push_interact_video: 'push_interact_video_enabled' };
      for (const [k, v] of Object.entries(map)) {
        if (k in f) cur[v] = b(f[k]); else if (v in f) cur[v] = b(f[v]);
      }
      all[me.id] = cur; wj('settings', all);
      return ok(res, cur);
    }

    /* feeds */
    const ctx = () => mkCtx();
    if (M === 'GET' && p === '/app/v4/feeds/androidfeed/') {
      const c = ctx(); const pg = paginate(videos().sort(byRecent), url, 10);
      return ok(res, { card_model_list: pg.items.map(v => vCard(v, req, me, c)), next_page: pg.next_page });
    }
    if (M === 'GET' && p === '/app/v4/feeds/discovery/') {
      const c = ctx(); const vs = videos().sort(byRecent);
      const groups = [group('HERO', 'Featured', 'hero', vs.slice(0, 5).map(v => vCard(v, req, me, c)))];
      const live = Object.keys(streams()).filter(id => streams()[id].live);
      if (live.length) groups.push(group('STREAM_LIST', 'Live Now', 'live', live.map(id => ({ card_type: 'STREAM', action_type: 'STREAM', images: { banner: phUrl(), icon: phUrl() }, title: streams()[id].name || '', sub_title: '', stream: streamJson(id, req) }))));
      groups.push(group('DETAIL', 'Recent Videos', 'recent', vs.slice(0, 20).map(v => vCard(v, req, me, c))));
      groups.push(group('WHO_TO_FOLLOW', 'Creators', 'creators', accounts().map(a => uCard(userJson(a.id, me, c)))));
      return ok(res, { group_set: { groups, next_page: null }, video_feeds: { feed_list: [] } });
    }
    if (M === 'GET' && (m = p.match(/^\/app\/v4\/feeds\/game\/([^/]+)$/))) {
      const g = findGame(m[1]); if (!g) return E.notFound(res);
      const c = ctx(); const id = String(g.game_primary_id);
      const pg = paginate(videos().filter(v => String(v.game_primary_id) === id).sort(byRecent), url, 10);
      return ok(res, group('DETAIL', g.name, 'game-' + id, pg.items.map(v => vCard(v, req, me, c)), pg.next_page));
    }
    if (M === 'GET' && (m = p.match(/^\/app\/v4\/feeds\/([^/]+)$/))) {
      const c = ctx(); const pg = paginate(sortFeed(videos(), 'TRENDING', c.likes), url, 10);
      return ok(res, group('HERO', '', m[1], pg.items.map(v => vCard(v, req, me, c)), pg.next_page));
    }

    /* jogos */
    if (M === 'GET' && p === '/app/v3/games') {
      const c = ctx(); const pg = paginate(games(), url, 20);
      return ok(res, group('DETAIL', 'Games', 'games', pg.items.map(g => gCard(g, me, c)), pg.next_page));
    }
    if (M === 'GET' && p === '/app/v3/kcp/games') {
      const c = ctx(); let list = games();
      if (url.searchParams.get('isAndroidOnly') === 'true') list = list.filter(g => g.play_store_id || !g.app_store_id);
      if (url.searchParams.get('isIOSOnly') === 'true') list = list.filter(g => g.app_store_id || !g.play_store_id);
      const start = Math.max(0, parseInt(url.searchParams.get('start'), 10) || 0);
      const count = Math.min(200, parseInt(url.searchParams.get('count'), 10) || 50);
      const items = list.slice(start, start + count);
      return ok(res, { game_list: items.map(g => gameJson(g, me, c)), next_page: start + count < list.length ? String((start + count)) : null });
    }
    if (M === 'POST' && p === '/app/v3/kcp/clientgames') {
      let ids = []; try { ids = JSON.parse((await readBody(req)).toString('utf8')); } catch {}
      ids = new Set(arr(ids).map(String)); const c = ctx();
      const list = games().filter(g => gameKeys(g).some(k => ids.has(k)));
      return ok(res, { game_list: list.map(g => ({ ...gameJson(g, me, c), isInstalled: true })), next_page: null });
    }
    if (M === 'GET' && p === '/app/v3/search/games') {
      const q = String(url.searchParams.get('query') || '').toLowerCase(); const c = ctx();
      const pg = paginate(games().filter(g => !q || String(g.name).toLowerCase().includes(q)), url, 20);
      return ok(res, { game_list: pg.items.map(g => gameJson(g, me, c)), next_page: pg.next_page });
    }
    if (M === 'POST' && p === '/app/v3/games/follow/batch') {
      let ids = []; try { ids = JSON.parse((await readBody(req)).toString('utf8')); } catch {}
      if (!me) return E.auth(res);
      const all = follows(); const f = fol(all, me.id); const out = [];
      for (const gid of arr(ids).map(String)) {
        const g = findGame(gid); if (!g) continue; const id = String(g.game_primary_id);
        if (!f.games.includes(id)) f.games.push(id);
        out.push({ follow_id: `${me.id}-g-${id}`, game_id: id });
      }
      wj('follows', all); return ok(res, { game_follow_list: out });
    }
    if ((m = p.match(/^\/app\/v3\/games\/([^/]+)(?:\/(follow|unfollow|followers|players|videos\/feed))?$/))) {
      const g = findGame(m[1]); const act = m[2] || '';
      if (!g) return E.notFound(res);
      const id = String(g.game_primary_id); const c = ctx();
      if (M === 'POST' && (act === 'follow' || act === 'unfollow')) {
        await readBody(req); if (!me) return E.auth(res);
        const all = follows(); const f = fol(all, me.id);
        f.games = f.games.filter(x => x !== id); if (act === 'follow') f.games.push(id);
        wj('follows', all); return ok(res, { follow_id: `${me.id}-g-${id}`, game_id: id });
      }
      if (M === 'GET') {
        if (act === '') return ok(res, gameJson(g, me, c));
        if (act === 'followers' || act === 'players') {
          const ids = act === 'followers'
            ? Object.entries(c.follows).filter(([, f]) => arr(f.games).includes(id)).map(([u]) => u)
            : [...new Set(c.videos.filter(v => String(v.game_primary_id) === id).map(v => String(v.user_id)))];
          const users = ids.map(u => userJson(u, me, c)).filter(Boolean);
          const pg = paginate(users, url, 20);
          return ok(res, { user_list: pg.items, next_page: pg.next_page, registered_UserCount: users.length, unregistered_UserCount: 0 });
        }
        if (act === 'videos/feed') {
          const list = sortFeed(c.videos.filter(v => String(v.game_primary_id) === id), url.searchParams.get('feedType') || 'RECENT', c.likes);
          const pg = paginate(list, url, 10);
          return ok(res, group('DETAIL', g.name, 'game-' + id, pg.items.map(v => vCard(v, req, me, c)), pg.next_page));
        }
      }
    }

    /* vídeos */
    if (M === 'GET' && p === '/app/v3/search/videos') {
      const q = String(url.searchParams.get('query') || '').toLowerCase(); const c = ctx();
      const list = videos().sort(byRecent).filter(v => !q || `${v.title} ${(findGame(v.game_primary_id) || {}).name || ''}`.toLowerCase().includes(q));
      const pg = paginate(list, url, 20);
      return ok(res, { video_list: pg.items.map(v => videoJson(v, req, me, c)), next_page: pg.next_page });
    }
    if ((m = p.match(/^\/app\/v3\/videos\/([^/]+)(?:\/(like|unlike|comments|comments\/add|updatestats))?$/))) {
      const vid = m[1], act = m[2] || '';
      const list = allVideosRaw(); const v = list.find(x => x.video_id === vid);
      if (!v) return E.notFound(res);
      if (M === 'GET' && act === '') return ok(res, videoJson(v, req, me, ctx()));
      if (M === 'DELETE' && act === '') {
        if (!me || String(v.user_id) !== String(me.id)) return E.auth(res);
        wj('videos', list.filter(x => x !== v));
        for (const f of [path.join(MEDIA, v.key), path.join(THUMBS, v.video_id + '.jpg')]) fs.rmSync(f, { force: true });
        return ok(res);
      }
      if (M === 'POST' && (act === 'like' || act === 'unlike')) {
        await readBody(req); if (!me) return E.auth(res);
        const l = rj('likes', {}); const a = arr(l[vid]).filter(x => x !== String(me.id));
        if (act === 'like') a.push(String(me.id));
        l[vid] = a; wj('likes', l); return ok(res);
      }
      if (M === 'POST' && act === 'updatestats') { await readBody(req); v.views = (v.views || 0) + 1; wj('videos', list); return ok(res); }
      if (M === 'GET' && act === 'comments') {
        const cm = arr(rj('comments', {})[vid]).sort((a, b) => String(b.added_at).localeCompare(String(a.added_at)));
        const pg = paginate(cm, url, 20); const c = ctx();
        return ok(res, { comment_list: pg.items.map(x => ({ ...x, user: userJson(x.user_id, me, c) })), next_page: pg.next_page });
      }
      if (M === 'POST' && act === 'comments/add') {
        const f = await fields(req); if (!me) return E.auth(res);
        const text = String(f.comment || '').trim().slice(0, 500); if (!text) return E.params(res);
        const all = rj('comments', {});
        const cm = { comment_id: crypto.randomUUID().replace(/-/g, ''), text, type: 'MANUAL', added_at: nowIso(), user_id: String(me.id), video_id: vid };
        (all[vid] = arr(all[vid])).push(cm); wj('comments', all);
        return ok(res, { ...cm, user: userJson(me.id, me, ctx()) });
      }
    }

    /* upload */
    if (M === 'POST' && p === '/app/v3/kcp/video/reserve') {
      const f = await fields(req); if (!me && !OPEN_MODE) return E.auth(res);
      const id = crypto.randomUUID().replace(/-/g, '');
      const vk = `videos/${id}.mp4`, ak = `audio/${id}.m4a`;
      log({ type: 'reserve', video_id: id, video_key: vk, voice_key: ak, user_id: me ? String(me.id) : 'local',
        title: String(f.user_title || f.default_title || '').slice(0, 120), game_id: String(f.game_id || ''), description: String(f.description || '').slice(0, 500) });
      return ok(res, {
        video_id: id,
        video_location: { bucket: 'kamcord-local', key: vk, url: '' },
        voice_location: { bucket: 'kamcord-local', key: ak, url: '' },
        credentials: { access_key_id: 'local', secret_access_key: 'local', session_token: 'local', expiration: null }
      });
    }
    if (M === 'POST' && p === '/app/v3/kcp/video/uploaded') {
      const f = await fields(req);
      log({ type: 'uploaded', data: f });
      return ok(res, {});
    }

    /* usuários */
    if (M === 'GET' && p === '/app/v3/search/users') {
      const q = String(url.searchParams.get('query') || '').toLowerCase(); const c = ctx();
      const list = accounts().filter(a => !q || a.username.toLowerCase().includes(q)).map(a => userJson(a.id, me, c));
      const pg = paginate(list, url, 20);
      return ok(res, { user_list: pg.items, next_page: pg.next_page, registered_UserCount: list.length, unregistered_UserCount: 0 });
    }
    if (M === 'GET' && p === '/app/v3/users/creators') {
      const c = ctx(); const pg = paginate(accounts(), url, 20);
      return ok(res, group('WHO_TO_FOLLOW', 'Creators', 'creators', pg.items.map(a => uCard(userJson(a.id, me, c))), pg.next_page));
    }
    if ((m = p.match(/^\/app\/v[34]\/users\/([^/]+)(?:\/(follow|unfollow|followers|following|videos\/feed|donate|flag))?$/)) && !p.includes('/color/')) {
      const uid = m[1], act = m[2] || ''; const c = ctx();
      const u = userJson(uid, me, c);
      if (!u) return E.notFound(res);
      if (M === 'GET' && act === '') return ok(res, u);
      if (M === 'POST' && (act === 'follow' || act === 'unfollow')) {
        await readBody(req); if (!me) return E.auth(res);
        if (String(me.id) === uid) return E.generic(res, 'Cannot follow yourself.');
        const all = follows(); const f = fol(all, me.id);
        f.users = f.users.filter(x => x !== uid); if (act === 'follow') f.users.push(uid);
        wj('follows', all); return ok(res, { follow_id: `${me.id}-u-${uid}` });
      }
      if (M === 'POST' && act === 'donate') { await readBody(req); return ok(res, { donation_id: '', donation_url: '' }); }
      if (M === 'POST' && act === 'flag') { await readBody(req); return ok(res); }
      if (M === 'GET' && (act === 'followers' || act === 'following')) {
        const ids = act === 'followers'
          ? Object.entries(c.follows).filter(([, f]) => arr(f.users).includes(uid)).map(([x]) => x)
          : arr(c.follows[uid] && c.follows[uid].users);
        const users = ids.map(x => userJson(x, me, c)).filter(Boolean); const pg = paginate(users, url, 20);
        return ok(res, { user_list: pg.items, next_page: pg.next_page, registered_UserCount: users.length, unregistered_UserCount: 0 });
      }
      if (M === 'GET' && act === 'videos/feed') {
        const pg = paginate(c.videos.filter(v => String(v.user_id) === uid).sort(byRecent), url, 10);
        return ok(res, { video_list: pg.items.map(v => videoJson(v, req, me, c)), next_page: pg.next_page });
      }
    }

    /* streams */
    if (M === 'GET' && p === '/app/v4/account/stream/key') {
      if (!me) return E.auth(res);
      const all = streams(); const s = all[me.id] || (all[me.id] = {});
      if (!s.stream_key) { s.stream_key = crypto.randomBytes(24).toString('hex'); s.url = 'rtmp://127.0.0.1/live'; wj('streams', all); }
      return ok(res, { stream_key: s.stream_key, url: s.url || 'rtmp://127.0.0.1/live' });
    }
    if (M === 'POST' && (p === '/app/v4/account/stream/start' || p === '/app/v4/account/stream/update')) {
      const f = await fields(req); if (!me) return E.auth(res);
      const all = streams(); const o = all[me.id] || {};
      all[me.id] = { ...o, live: true, connected: false, ended_at: null, game_id: String(f.game_id || o.game_id || ''),
        name: String(f.name || o.name || me.username).slice(0, 120), started_at: o.live ? o.started_at : nowIso(),
        stream_session_id: o.live ? o.stream_session_id : crypto.randomUUID(),
        stream_key: o.stream_key || crypto.randomBytes(24).toString('hex'), url: o.url || 'rtmp://127.0.0.1/live' };
      wj('streams', all); return ok(res, streamJson(me.id, req));
    }
    if (M === 'POST' && p === '/app/v4/account/stream/stop') {
      await readBody(req); if (!me) return E.auth(res);
      const all = streams(); if (all[me.id]) { all[me.id].live = false; all[me.id].connected = false; all[me.id].ended_at = nowIso(); wj('streams', all); }
      return ok(res);
    }
    if ((m = p.match(/^\/app\/v4\/streams\/([^/]+)(?:\/(message|heart|ban|unban|timeout|untimeout|hide))?$/))) {
      const sid = m[1], act = m[2] || '';
      if (M === 'GET' && act === '') return ok(res, streamJson(sid, req));
      if (M === 'GET' && act === 'message') {
        const c = ctx(); const l = arr(rj('messages', {})[sid]); const pg = paginate(l, url, 50);
        return ok(res, { messages: pg.items.map(x => ({ ...x, user: userJson(x.user_id, me, c) })), next_page: pg.next_page });
      }
      if (M === 'POST' && act === 'message') {
        const f = await fields(req); if (!me) return E.auth(res);
        const all = rj('messages', {});
        const msg = { stream_id: sid, text: String(f.text || '').slice(0, 300), type: 'NORMAL', added_at: nowIso(), user_id: String(me.id), error_message: null };
        (all[sid] = arr(all[sid])).push(msg); wj('messages', all);
        return ok(res, { ...msg, user: userJson(me.id, me, ctx()) });
      }
      if (M === 'POST' && act === 'heart') {
        await readBody(req); const all = streams();
        if (all[sid]) { all[sid].heart_count = (all[sid].heart_count || 0) + 1; wj('streams', all); }
        return ok(res);
      }
      if (M === 'POST') { await readBody(req); return ok(res); } // ban/unban/timeout/untimeout/hide
    }

    // Qualquer outra rota da API: resposta no formato do app (nunca erro HTTP cru).
    if (p.startsWith('/app/')) return fail(res, 9, 'Unsupported endpoint.');
    return json(res, { error: 'Not found', path: p }, 404);
  } catch (err) {
    console.error('[ERROR]', err);
    if (!res.headersSent) json(res, { status: { status_code: 8, status_reason: 'Internal server error' }, response: null }, 500);
    else res.destroy();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('Kamcord local server v2 iniciado');
  console.log(`API: http://127.0.0.1:${PORT}   Armazenamento: ${ROOT}`);
  if (OPEN_MODE) console.log('AVISO: KAMCORD_OPEN=1 (sem exigir token)');
});
