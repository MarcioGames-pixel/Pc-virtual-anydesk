# Kamcord local server v2

Substitui `server.js` e `video-catalog.js` (pode apagar o `video-catalog.js`).

## Como usar (Termux)
    cd ~/kamcord && node server.js
Usa `~/kamcord-storage` (mesmos arquivos de antes). Na primeira execução migra
`videos-catalog.json` e `game-follows.json` para `videos.json` e `follows.json`.
Faça backup da pasta `kamcord-storage` antes.

Variáveis opcionais: `PORT=42480`, `KAMCORD_STORAGE=/caminho`,
`KAMCORD_OPEN=1` (modo antigo: sem token usa a última conta - só para teste).
Com `ffmpeg` instalado (`pkg install ffmpeg`) gera miniatura e duração dos vídeos.

## O que foi corrigido (comparado ao APK 1.7-38)
- Home, Discovery, aba Games e /kcp/games vinham VAZIOS; agora listam vídeos/jogos reais.
- Título e jogo do vídeo agora vêm do `reserve` (o `uploaded` do app não manda título).
- Vídeo fica ligado ao dono (token) e ao video_id reservado; URLs são geradas pelo host da requisição (não ficam fixas em 127.0.0.1 no JSON).
- Configurações de notificação: o app envia `push_comments` etc. (sem `_enabled`); antes nunca salvava.
- Rotas que o app chama e não existiam: like/unlike, comentários, views, apagar vídeo,
  seguir/deixar de seguir usuário, seguidores/seguindo, batch follow de jogos, clientgames,
  feeds/game/{id}, validação de usuário/e-mail/senha, trocar e-mail/senha, token push,
  mensagens/coração/ban do stream, flag, donate, trackevent.
- Códigos de status agora são os reais do app (ENTITY_NOT_FOUND=9, GENERIC_ERROR=8...).
- Removido o "fallback" que tratava qualquer requisição sem token como a conta nº 2.
- Upload grava em disco por streaming (menos memória), preserva `audio/` e responde ETag no PUT simples.
- Rotas desconhecidas devolvem JSON no formato do app (antes: HTTP 400 cru).

## Limites
- Testado com curl simulando o app; não testei no aparelho.
- Os tipos de grupo/cartão da Discovery (HERO, DETAIL, WHO_TO_FOLLOW, STREAM_LIST) seguem os
  modelos do APK, mas o layout exato pode precisar de ajuste vendo o app rodando.
- Não há RTMP/HLS real: o "ao vivo" só guarda estado.

## Se o app crashar (diagnóstico)
Desligue telas uma a uma e veja qual causa o crash:

    KAMCORD_EMPTY=hero,games,creators node server.js

Opções: `hero`, `games`, `creators`, `home`, `discovery`. Guarde o log com
`node server.js 2>&1 | tee ~/kamcord.log`; as últimas linhas `[REQ]` mostram a tela que derrubou.

## v2.1
- Experimentos voltaram a responder `experiments: []` (como na versão antiga).
- Nenhuma imagem sai nula/vazia: ícones, avatares e miniaturas usam `/placeholder.png`
  (o Picasso do app lança exceção com URL vazia).
- Vídeos cujo arquivo falta ou tem menos de 1 KB (ex.: o `teste.mp4` de 29 bytes) não aparecem nos feeds.

## v2.2
- **Corrigido o crash**: o app faz `Color.parseColor(profile_color)` na lista de criadores e o servidor
  mandava `"default"`. Agora a cor é sempre hexadecimal (`#RRGGBB`); valores antigos viram `#7E57C2`.
