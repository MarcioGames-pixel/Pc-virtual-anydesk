const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const ROOT = path.join(os.homedir(), 'kamcord-storage');
const UPLOADS = path.join(ROOT, 'uploads.json');
const GAMES = path.join(ROOT, 'games.json');
const ACCOUNTS = path.join(ROOT, 'accounts.json');
const CATALOG = path.join(ROOT, 'videos-catalog.json');

function read(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return fallback; }
}

function write(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

function publicBase(req) {
  const proto = String(req.headers['x-forwarded-proto'] || 'http').split(',')[0];
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '127.0.0.1:42480').split(',')[0];
  return `${proto}://${host}`;
}

function getVideos(req) {
  const uploads = read(UPLOADS, []);
  const catalog = read(CATALOG, []);
  const games = read(GAMES, []);
  const accounts = read(ACCOUNTS, []);
  const base = publicBase(req);
  const map = new Map();

  // Mantém IDs persistentes criados pelo catálogo.
  for (const v of catalog) {
    if (v && v.video_id) map.set(String(v.video_id), v);
  }

  for (const u of uploads) {
    if (!u || u.type !== 's3-complete' || !u.key) continue;

    const key = String(u.key).replace(/^\/+/, '');
    const filename = path.basename(key);
    const diskFile = path.join(ROOT, 'kamcord-local', key);
    if (!fs.existsSync(diskFile) || !fs.statSync(diskFile).isFile()) continue;

    // Usa ID estável derivado da chave do arquivo.
    const id = 'local-' + Buffer.from(key).toString('hex').slice(0, 48);
    if (map.has(id)) continue;

    const reserve = uploads.find(x =>
      x && x.type === 'reserve' &&
      (x.video_key === key || x.video_key === key.replace(/^videos\//, ''))
    );
    const uploaded = uploads.find(x =>
      x && x.type === 'uploaded' &&
      x.data && String(x.data.video_id || '') === String(reserve?.video_id || '')
    );

    const ownerId = String(uploaded?.data?.user_id || uploaded?.data?.user?.id || '');
    const owner = accounts.find(a => String(a.id) === ownerId);
    const game = games.find(g =>
      String(g.game_primary_id) === String(uploaded?.data?.game_primary_id || '') ||
      String(g.play_store_id || '') === String(uploaded?.data?.game_primary_id || '')
    );

    map.set(id, {
      video_id: id,
      title: uploaded?.data?.title || path.parse(filename).name || 'Video',
      game_primary_id: game?.game_primary_id || uploaded?.data?.game_primary_id || '',
      game_name: game?.name || uploaded?.data?.game_name || 'My Talking Tom',
      user_id: ownerId || 'local',
      username: owner?.username || 'local',
      duration: Number(uploaded?.data?.duration || 0),
      comments: 0,
      hearts: 0,
      likes: 0,
      reshares: 0,
      views: 0,
      featured: false,
      is_user_liking: false,
      is_user_resharing: false,
      vod: true,
      video_state: 'PROCESSED',
      video_url: `${base}/kamcord-media/${encodeURIComponent(key)}`,
      video_site_watch_page: `${base}/app/v3/videos/${encodeURIComponent(id)}`,
      thumbnails: { regular: null, small: null },
      upload_time: u.created_at || new Date().toISOString(),
      source: { message: '', type: 'UPLOAD' },
      _file: diskFile,
      _key: key
    });
  }

  const videos = [...map.values()];
  write(CATALOG, videos);
  return videos;
}

function asVideo(v) {
  const { _file, _key, ...out } = v;
  return out;
}

function handle(req, res, pathname, url, json, accountStatus) {
  const base = publicBase(req);

  // Entrega do arquivo enviado, com suporte a requisições Range.
  if (req.method === 'GET' && pathname.startsWith('/kamcord-media/')) {
    let key;
    try { key = decodeURIComponent(pathname.slice('/kamcord-media/'.length)); }
    catch { return json(res, { error: 'Invalid media path' }, 400); }

    if (!key || key.includes('..') || key.startsWith('/')) {
      return json(res, { error: 'Invalid media path' }, 400);
    }
    const file = path.resolve(ROOT, 'kamcord-local', key);
    const mediaRoot = path.resolve(ROOT, 'kamcord-local') + path.sep;
    if (!file.startsWith(mediaRoot) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      return json(res, { error: 'Media not found' }, 404);
    }

    const size = fs.statSync(file).size;
    const range = req.headers.range;
    const ext = path.extname(file).toLowerCase();
    const type = ext === '.mp4' ? 'video/mp4' :
      ext === '.m4v' ? 'video/x-m4v' :
      ext === '.webm' ? 'video/webm' : 'application/octet-stream';

    res.setHeader('Content-Type', type);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Access-Control-Allow-Origin', '*');

    if (range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!m) return json(res, { error: 'Invalid range' }, 416);
      let start = m[1] ? Number(m[1]) : 0;
      let end = m[2] ? Number(m[2]) : size - 1;
      if (!m[1] && m[2]) {
        const suffix = Number(m[2]);
        start = Math.max(0, size - suffix);
        end = size - 1;
      }
      if (start >= size || end < start) {
        res.writeHead(416, { 'Content-Range': `bytes */${size}` });
        return res.end();
      }
      end = Math.min(end, size - 1);
      res.writeHead(206, {
        'Content-Length': end - start + 1,
        'Content-Range': `bytes ${start}-${end}/${size}`
      });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(file, { start, end }).pipe(res);
    }

    res.writeHead(200, { 'Content-Length': size });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(file).pipe(res);
  }

  if (req.method !== 'GET') return false;

  const detail = pathname.match(/^\/app\/v3\/videos\/([^/]+)\/?$/);
  if (detail) {
    const id = decodeURIComponent(detail[1]);
    const video = getVideos(req).find(v => String(v.video_id) === id);
    if (!video) return json(res, accountStatus(1, 'Video not found.', null), 404);
    return json(res, accountStatus(0, 'All ok.', asVideo(video)));
  }

  if (pathname === '/app/v3/search/videos') {
    const query = String(url.searchParams.get('query') || '').toLowerCase();
    const page = Math.max(0, Number(url.searchParams.get('page') || 0));
    const videos = getVideos(req).filter(v =>
      `${v.title} ${v.game_name} ${v.username}`.toLowerCase().includes(query)
    );
    return json(res, accountStatus(0, 'All ok.', {
      video_list: videos.slice(page * 20, page * 20 + 20).map(asVideo),
      next_page: (page + 1) * 20 < videos.length ? String(page + 1) : null
    }));
  }

  return false;
}

function gameFeed(req, game) {
  const videos = getVideos(req).filter(v =>
    String(v.game_primary_id) === String(game.game_primary_id) ||
    String(v.game_primary_id) === String(game.play_store_id || '')
  );
  return {
    group_type: 'DETAIL',
    title: game.name || '',
    feed_id: 'game-' + game.game_primary_id,
    card_models: videos.map(v => ({
      card_type: 'VIDEO',
      action_type: 'VIDEO',
      title: v.title,
      sub_title: v.username,
      video: asVideo(v),
      game
    })),
    next_page: null
  };
}

module.exports = { handle, gameFeed, getVideos };
